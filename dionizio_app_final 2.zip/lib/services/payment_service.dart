// Payment service placeholders
// PIX configured with client's CPF as key by default.
// Replace placeholders with your real keys and secure secrets.

class PaymentService {
  // PIX: using 'key' mode with CPF provided
  static const pixMode = 'key'; // 'key' or 'gateway'
  static const pixKey = '13287562460'; // CPF fornecido pelo cliente

  // Stripe placeholders for card payments
  static const stripePublishableKey = '<STRIPE_PUBLISHABLE_KEY>';
  static const stripeSecretKey = '<STRIPE_SECRET_KEY>'; // use only in server / cloud function

  // For testing within the mobile app, this function simulates a payment flow.
  static void testPayment() {
    print('Simulando pagamento: Pix mode=\$pixMode, PixKey=\$pixKey, Stripe key=\$stripePublishableKey');
  }
}
