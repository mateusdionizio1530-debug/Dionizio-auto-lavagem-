import 'package:flutter/material.dart';

final appTheme = ThemeData(
  brightness: Brightness.dark,
  primaryColor: Color(0xFFE02720),
  scaffoldBackgroundColor: Colors.black,
  colorScheme: ColorScheme.dark(primary: Color(0xFFE02720)),
);
