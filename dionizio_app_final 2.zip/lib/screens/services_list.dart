import 'package:flutter/material.dart';

class ServicesListScreen extends StatelessWidget {
  final services = [
    {'title':'Lavagem simples','price':30,'duration':30},
    {'title':'Lavagem com polimento','price':80,'duration':60},
    {'title':'Lavagem premium','price':120,'duration':90},
    {'title':'Higienização interna','price':150,'duration':60},
    {'title':'Polimento manual','price':200,'duration':120},
    {'title':'Lavagem de motor','price':70,'duration':45},
    {'title':'Detalhamento de chassi','price':180,'duration':150},
  ];

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Serviços')),
      body: ListView.builder(
        itemCount: services.length,
        itemBuilder: (ctx,i){
          final s = services[i];
          return Card(
            color: Colors.white10,
            child: ListTile(
              title: Text(s['title'].toString()),
              subtitle: Text('R\$ \${s['price']} - \${s['duration']} min'),
            ),
          );
        }
      ),
    );
  }
}
