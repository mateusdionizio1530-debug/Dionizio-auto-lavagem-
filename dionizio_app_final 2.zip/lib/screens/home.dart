import 'package:flutter/material.dart';
import 'services_list.dart';
import 'schedule.dart';
import '../services/payment_service.dart';

class HomeScreen extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Dionizio Auto Lavagem')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children:[
            ElevatedButton(
              onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=> ServicesListScreen())),
              child: Text('Serviços')
            ),
            SizedBox(height:12),
            ElevatedButton(
              onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=> ScheduleScreen())),
              child: Text('Agendar')
            ),
            SizedBox(height:12),
            ElevatedButton(
              onPressed: ()=> PaymentService.testPayment(),
              child: Text('Testar Pagamento (simulação)')
            ),
          ]
        )
      ),
    );
  }
}
