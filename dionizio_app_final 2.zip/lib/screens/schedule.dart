import 'package:flutter/material.dart';

class ScheduleScreen extends StatelessWidget {

  // Operating hours and capacity (from client)
  final String open = "08:00";
  final String close = "17:00";
  final int dailyCapacity = 10; // máximo 10 carros por dia

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Agendar')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children:[
            Text('Funcionamento: \$open às \$close', style: TextStyle(fontSize:16)),
            SizedBox(height:12),
            Text('Capacidade diária: \$dailyCapacity carros', style: TextStyle(fontSize:16)),
            SizedBox(height:20),
            Expanded(child: Center(child: Text('Tela de agendamento inteligente (slots fixos + intervalos + cálculo automático por capacidade)'))),
          ]
        )
      ),
    );
  }
}
