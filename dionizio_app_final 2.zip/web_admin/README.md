Admin web (esqueleto)
- Pasta reservada para o painel admin em React (Firebase).
- Posso gerar o painel com as telas: login admin, dashboard, agendamentos, CRUD serviços, relatórios.
